//Question 1 - basic STL

//Task 1: improve fill_vector and vecOfVec.push_back performance - execution time can be reduced significantly, please explain the changes you made and how they improve
// the application performance.

//explanation: instead of push_back, I declared initialize vector with the rewuired size and the used the operator [] to add the elements to the vetor (same idea in main)
//push_back does a bounds check. operator[] does not. So even if you've reserved the space, push_back is going to have an extra conditional check that the operator [] will not have. 
//also, it will increase the size value, so it will update that every time. that's why push_back take much more time

//Task 2: Implement count_total_elements without using a "visible" for loop

//Task 3: Implement merge_vec_of_vec 

// Make sure you compile the code in "Release" configuration (e.g O2 optimization level).
// Do not modify ELEMENT_COUNT and ITERATIONS and functions fill_vector,count_total_elements and merge_vec_of_vec function signatures  

#include <chrono>
#include <iostream>
#include <vector>

constexpr size_t ELEMENT_COUNT = 1000 * 10000;
constexpr size_t ITERATIONS = 10;

std::vector<uint64_t> fill_vector(size_t elementCount) {
	//TODO: improve function performance
	std::vector<uint64_t> vec(elementCount); //improving function performance using []
	for (size_t i = 0; i < elementCount; i++) {
		vec[i] = i;
	}
	return vec;
}

/// This function should return the total elements in all of the vectors
size_t count_total_elements(const std::vector<std::vector<uint64_t>>& vecOfVec) {
	int outerVec = vecOfVec.size();
	size_t counter = 0;
	//int innerVev = vecOfVec[0].size();
	//using iterator to access the vector elements
	for (std::vector<uint64_t> vect1D : vecOfVec)
	{
		for (int x : vect1D)
		{
			counter++;
		}
	}
	return counter;
}

/// This function should return a single vector that contain all of the elements of the vectors in vecOfVec
std::vector<uint64_t> merge_vec_of_vec(std::vector<std::vector<uint64_t>>& vecOfVec) {
	std::vector<uint64_t> mergedVec;
	//TODO: Your code here
	size_t iterr1 = vecOfVec.size();
	mergedVec.reserve(iterr1*vecOfVec[0].size()); // work for me with 10^7 , but didnt workd with 10^8
													// tried diffrent ways but didnt work.
	for (size_t i = 0; i < iterr1; i++)
	{
		size_t temp = vecOfVec[i].size();
		for (size_t j = 0; j < 1000000; j++)
		{
			mergedVec.push_back(j);
		}
		//mergedVec.resize(ELEMENT_COUNT*(i+1));
	}
	return mergedVec;
}

int main(int argc, char** argv)
{
	//Create vector of vectors
	std::vector<std::vector<uint64_t>> vecOfVec(ITERATIONS);
	auto start = std::chrono::steady_clock::now();
	for (size_t i = 0; i < ITERATIONS; i++) {
		std::vector<uint64_t> vec = fill_vector(ELEMENT_COUNT);
		//TODO: improve inserting performance
		vecOfVec[i] = vec;
	}
	auto end = std::chrono::steady_clock::now();
	size_t averageIterationTimeUs = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count() / ITERATIONS;
	std::cout << "Average iteration duration in microseconds: " << averageIterationTimeUs << std::endl;

	//Count elements
	size_t totalElements = count_total_elements(vecOfVec);
	std::cout << "Total elements in vecOfVec: " << totalElements << " " << std::endl;

	//Merge vector of vectors
	std::vector<uint64_t> mergedVec = merge_vec_of_vec(vecOfVec);
	std::cout << "Total elements in merged mergedVec: " << mergedVec.size() << std::endl;

	std::cout << "Press enter to exit" << std::endl;
	getchar();
	return 0;
}