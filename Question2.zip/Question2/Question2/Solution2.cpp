//Question 2 - threads & synchronization

//Task: Improve execution time by using multi-threading instead of calling operation1 and operation2 serially, make sure that sum=EXPECTED_SUM after using threads
// please explain the changes you made and what new aspects you had to deal with when shifting from serial execution to parallel execution 

// Make sure you compile the code in "Release" configuration (e.g O2 optimization level).
// Do not modify the constexpr variables

#include <chrono>
#include <iostream>
#include <vector>
#include <thread>

constexpr size_t ITERATIONS = 1000 * 1000ULL;
constexpr size_t OP1_PARAM = 2ULL;
constexpr size_t OP2_PARAM = 1ULL;
constexpr size_t EXPECTED_SUM = 1000001000000ULL;

size_t sum1 = 0; // sum = sum1 + sum2 ,they are now indepandble so we can run both function simultaneously for parallel execution
size_t sum2 = 0;
//This paralle execution returns maximum{op1,op2} time, instead of op1+op2 serial execution so indeed improvong execution time

//std::mutex mtx1, mtx2; //declare two mutex objects

void operation1(size_t arg) {
	std::cout << "Performing operation1" << std::endl;
	//mtx1.lock();
	for (size_t i = 0; i < ITERATIONS; i++) {
		sum1 += (arg + i);
	}
	//mtx1.unlock();
	std::this_thread::sleep_for(std::chrono::seconds(5)); //Simulate some heavy work
	std::cout << "Operation1 Performed" << std::endl;
}


void operation2(size_t arg) {
	std::cout << "Performing operation2" << std::endl;
	//mtx2.lock();
	for (size_t i = 0; i < ITERATIONS; i++) {
		sum2 += (arg*i);
	}
	//mtx2.unlock();
	std::this_thread::sleep_for(std::chrono::seconds(10));  //Simulate some heavy work
	std::cout << "Operation2 Performed" << std::endl;
}


int main(int argc, char** argv)
{
	auto start = std::chrono::steady_clock::now();
	std::thread thread1(operation1, OP1_PARAM); //thread 1 runs on opertation1 function
	std::thread thread2(operation2, OP2_PARAM); //thread 2 runs on operation2 function
	thread1.join();  // synchronazation
	thread2.join();
	//operation1(OP1_PARAM);
	//operation2(OP2_PARAM);
	auto end = std::chrono::steady_clock::now();

	std::cout << "Total execution duration in milliseconds: " << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() << std::endl;
	std::cout << "Result:  " << (sum1 + sum2) << ", " << ((sum1 + sum2) == EXPECTED_SUM ? "success" : "failure!") << std::endl;
	std::cout << "Press enter to exit" << std::endl;
	getchar();
	return 0;
}