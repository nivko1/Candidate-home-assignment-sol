//Question 4 - Filesystem & args  

// Task: Implement the code as described in the main body, make sure to handle cases when the requested file is not found or the "files" directory doesn't exists and you have to create it
// Prefer modern solutions over classic C style solutions and keep in mind that this code should be able to run in other windows, linux and other platforms (hint: '/' and '\' in file paths)


#include <iostream>
#include <fstream>
#include <string>
#include <direct.h>
#define mkdir(dir, mode) _mkdir(dir) // if we want to compile as c file in linux
#pragma warning(disable : 4996) // for strcat warnings

int main(int argc, char** argv)
{
	if (argc != 4) // if user didnt match the equal arguments required
	{
		perror("Please enter 3 arguments\n");
		exit(1);
	}
	const char* arg3 = argv[3]; //take arguemrnt3 any set it into variable
	char warg[20];
	strcpy(warg, arg3);
	char option1[] = "create";
	char option2[] = "read";
	char* wFile = argv[2]; //build path
	strcat(wFile, ".txt");
	char path[20] = "files/";
	strcat(path, wFile);
	if (strcmp(option1, argv[1]) == 0) // chaeck if choose "create"
	{
		int check;
		const char* directory = "files";  // creating folder with name "files"
		check = mkdir(directory, 0755);
		// check if folder is created or not
		if (!check)
			printf("Directory files created\n");
		else {
			printf("Unable to create directory\n");
			exit(1);
		}
		std::ofstream myFile(path); //creating the text file with argument2 name opent it
		if (myFile.is_open())
		{
			myFile << "Hello from " << warg; //write to text file Hello from argument3
		}
		myFile.close();
	}
	else if (strcmp(option2, argv[1]) == 0) // if choose "read"
	{
		std::string line;
		std::ifstream myFile(path); //opent txt file with path
		if (myFile.is_open())
		{
			std::getline(myFile, line); //read from txt
			std::cout << line << '\n'; //print on screeen
			myFile.close();
		}
		else std::cout << "Unable to open file";
	}
	else
	{
		std::cout << "Please write create or read in the first argument\n";
	}

	//If user passed "create" argument 
	//		Create (or overwrite) a file named *argument2.txt*  with the text "Hello from *argument3*" in a folder named "files" under the current working directory  
	//else if user passed "read" argument 
	//		read a file named* argument2* from a folder named "files" under the current working directory and print it to the console

	//Execution example (assuming working directory c:\code): question04.exe create test1 Nir - should create the file c:\code\files\test1.txt with the content "Hello from Nir"
	//Execution example (assuming working directory c:\code): question04.exe read test1  - should print "Hello from Nir" in the console (assuming the previous command was executed) 

	std::cout << "Press enter to exit" << std::endl;
	getchar();
	return 0;
}