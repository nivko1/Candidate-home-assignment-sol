//Question 3 - pointers

// There is a memory leak in the code below, where is it?, what class/solution can you use to fix it while ensuring that the object will be deleted only once and only when it's not used by any consumer
// Task: Modify the code to address the issues above. Please explain the changes you made and how they solve the memory allocation/deletion issue  

// Do not remove any function or change threads dispatching order - you can(and should) change the functions body/signature

// explanation: The C++ operator "new" allocates heap memory. The delete operator frees heap memory. 
// For every "new",we need to use "delete" so that you free the same memory you allocated
//Since the thread in this program continue and no synchronized, the last one who use the object shuld delete it.
#include <chrono>
#include <iostream>
#include <vector>
#include <thread>
#include <random>
#include <crtdbg.h> //check memory leaks 
#include <atomic>

struct Payload {

	Payload(uint64_t id_) :
		id(id_),
		veryLargeVector(1000 * 1000),
		counter(0)
	{}
	~Payload() {}
	std::atomic<int> counter; // add atomic int so we have read modify right and no race condition
	uint64_t id;
	std::vector<int> veryLargeVector;
};

void operation1(Payload* payload) {
	std::cout << "Performing operation1 on payload " << payload->id << std::endl;
	std::this_thread::sleep_for(std::chrono::seconds(5 + (std::rand() % (12 - 5 + 1))));  //Simulate some heavy work
	std::cout << "Operation1 Performed" << std::endl;
	payload->counter++;
	if (payload->counter == 2)
	{
		delete payload;
		std::cout << "Delete object safely from operation1\n";
	}
}

void operation2(Payload* payload) {
	std::cout << "Performing operation2 on payload " << payload->id << std::endl;
	std::this_thread::sleep_for(std::chrono::seconds(std::chrono::seconds(5 + (std::rand() % (12 - 5 + 1)))));  //Simulate some heavy work
	std::cout << "Operation2 Performed" << std::endl;
	payload->counter++;
	if (payload->counter == 2)
	{
		delete payload;
		std::cout << "Delete object safely from operation2\n";
	}
}

void dispacher_thread() {
	Payload* payload = new Payload(1);
	std::this_thread::sleep_for(std::chrono::seconds(2));  //Simulate some heavy work
	std::thread wt1(&operation1, payload);
	std::thread wt2(&operation2, payload);
	//Waiting for wt1 & wt2 to finish is not allowed, dispacher_thread should exit after creating wt1 and wt2
	wt1.detach();
	wt2.detach();
	//payload->~Payload();
}

int main(int argc, char** argv)
{
	std::cout << "Calling dispatcher thread" << std::endl;
	std::thread t(&dispacher_thread);
	t.join();

	std::cout << "Press enter to exit" << std::endl;
	getchar();
	//_CrtDumpMemoryLeaks(); used this to check memory leak
	return 0;
}